$(document).ready(function(){
    var row = 1;
    var pokedex = 1;
    var temp= "<img src='http://pokeapi.co/media/img/";
    var end = ".png'>";
    var divHTML1 = "<div class='row' id='row-";
    var divHTML2 = "'></div>"
    
    //fifteen rows with 10 elements in each row
    //add the last 151st pokemon manually
    for(var i = 1; i<16; i++){
        $(".container").append(divHTML1+row+divHTML2);
        for(var j = 0; j<10; j++){
            $("#row-"+row).append(temp+pokedex+".png'>");
            pokedex++;
        }
        row++;


        // $("h1").next().append(temp+i+".png'>");
        // console.log(temp+i);
    }
    console.log(pokedex);
    $(".container").append(divHTML1+row+divHTML2);
    $("#row-"+row).append(temp+pokedex+".png'>");

    
});